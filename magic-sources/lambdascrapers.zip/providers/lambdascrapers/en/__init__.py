# -*- coding: utf-8 -*-

import hosters
import torrent

def get_hosters():
    return hosters.__all__

