import requests, re, threading

from bs4 import BeautifulSoup
from resources.lib.common.tools import quote_plus
from resources.lib.common import source_utils

class sources:

    def __init__(self):
        self.base_link = "https://1337x.to"
        self.search_link = "/search/%s/1/"
        self.threads = []
        self.singleThreads = []
        self.packThreads = []
        self.headers = {'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X x.y; rv:42.0) Gecko/20100101 Firefox/42.0'}
        self.torrent_list = []

    def searchResults(self, response):

        soup = BeautifulSoup(response.text, 'html.parser')
        search_results = soup.find('table', {'class': 'table-list'})
        search_results = search_results.find('tbody')
        search_results = search_results.findAll('tr')


        return search_results


    def info_thread(self, release_title, url, package):
        url = self.base_link + url
        response = requests.get(url, headers=self.headers)
        torrent = {}
        torrent['package'] = package
        torrent['release_title'] = release_title
        torrent['magnet'] = re.findall(r'href="(magnet:?.*?)"', response.text)[0]
        self.torrent_list.append(torrent)

    def movie(self, title, year):

        url = self.search_link % quote_plus('%s %s' % (title, year))
        url = self.base_link + url
        response = requests.get(url, headers=self.headers)
        soup = BeautifulSoup(response.text, 'html.parser')
        search_results = soup.find('table', {'class': 'table-list'})
        search_results = search_results.find('tbody')
        search_results = search_results.findAll('tr')
        for i in search_results:
            release = i.findAll('a')[1]
            url = release['href']
            release_title = release.text
            if source_utils.filterMovieTitle(release_title, title, year):
                self.threads.append(threading.Thread(target=self.info_thread, args=(release_title, url, 'single')))

        for i in self.threads:
            i.start()
        for i in self.threads:
            i.join()

    def episode(self, simpleInfo, allInfo):

        self.threads.append(threading.Thread(target=self.seasonPack, args=(simpleInfo, allInfo)))
        self.threads.append(threading.Thread(target=self.singleEpisode, args=(simpleInfo, allInfo)))

        for thread in self.threads:
            thread.start()
        for thread in self.threads:
            thread.join()

        return self.torrent_list

    def singleEpisode(self, simpleInfo, allInfo):

        season = simpleInfo['season_number'].zfill(2)
        episode = simpleInfo['episode_number'].zfill(2)

        query = quote_plus(simpleInfo['show_title'] + ' s%se%s' % (season, episode))

        url = self.base_link + self.search_link % query
        print(url)
        try:
            search_results = self.searchResults(requests.get(url, headers=self.headers))
        except:
            import traceback
            traceback.print_exc()
            return

        for i in search_results:
            release = i.findAll('a')[1]
            url = release['href']
            release_title = release.text
            if source_utils.filterSingleEpisode(release_title, simpleInfo['show_title'], simpleInfo['season_number'],
                                                simpleInfo['episode_number'],simpleInfo['show_aliases'],
                                                simpleInfo['year'], simpleInfo['country']):
                self.singleThreads.append(threading.Thread(target=self.info_thread, args=(release_title, url, 'single')))

        for i in self.singleThreads:
            i.start()
        for i in self.singleThreads:
            i.join()

        return

    def seasonPack(self, simpleInfo, allInfo):

        season = simpleInfo['season_number']

        query = quote_plus(simpleInfo['show_title'] + ' season %s' % season)

        url = self.base_link + self.search_link % query

        try:
            search_results = self.searchResults(requests.get(url, headers=self.headers))
        except:
            import traceback
            traceback.print_exc()
            return

        for i in search_results:
            release = i.findAll('a')[1]
            url = release['href']
            release_title = release.text
            if source_utils.filterSeasonPack(release_title, simpleInfo['show_title'], simpleInfo['season_number'],
                                             simpleInfo['show_aliases'], simpleInfo['year'], simpleInfo['country']):
                self.packThreads.append(threading.Thread(target=self.info_thread, args=(release_title, url, 'pack')))

        for i in self.packThreads:
            i.start()
        for i in self.packThreads:
            i.join()

        return
