import json, requests

class sources:

    def __init__(self):
        self.base_link = ' https://torrentapi.org/pubapi_v2.php'

    def get_token(self):
        response = requests.get('https://yts.am/torrent/download/5D77A6DADC928C75A43492A655C0B94A4874E786')



s = sources()
s.get_token()