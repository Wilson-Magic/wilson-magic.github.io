import requests, threading, re

from bs4 import BeautifulSoup
from resources.lib.common.tools import quote_plus
from resources.lib.common import source_utils
from resources.lib.common import cfscrape


class sources:

    def __init__(self):
        self.base_link = 'https://rarbg.to'
        self.search_link = '/torrents.php?search=%s'
        self.movie_categories = '&category%5B%5D=14&category%5B%5D=48&category%5B%5D=17&category%5B%5D=44&category%5B%5D=45&category%5B%5D=47&category%5B%5D=50&category%5B%5D=51&category%5B%5D=52&category%5B%5D=42&category%5B%5D=46'
        self.threads=[]
        self.torrent_list = []
        self.session = requests.Session()

    def movieThread(self, url, release_title):
        print(url)
        url = self.base_link + url
        response = self.session.get(url)
        torrent = {}
        torrent['type'] = 'torrent'
        torrent['release_title'] = release_title
        torrent['quality'] = source_utils.getQuality(release_title)
        torrent['info'] = source_utils.getInfo(release_title)
        torrent['magnet'] = re.findall(r'href="(magnet:?.*?)"', response.text)[0]
        torrent['hash'] = re.findall(r'btih:(.*?)\&', torrent['magnet'])[0]
        print(str(torrent))
        self.torrent_list.append(torrent)

    def movie(self, title, year):
        headers = {'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X x.y; rv:42.0) Gecko/20100101 Firefox/42.0'}
        print(self.session.get(self.base_link, headers=headers).text)
        url = quote_plus('%s %s' % (title, year))
        url = self.base_link + (self.search_link % url) + self.movie_categories
        response = self.session.get(url)
        print(response.url)
        soup = BeautifulSoup(response.text, 'html.parser')
        search_results = soup.find_all('td', {'class':'lista'})

        for i in search_results:
            try:
                release = i.find('a')
                release_title = release.text
                print(release_title)
            except: continue
            if source_utils.filterMovieTitle(release_title, title, year):
                self.threads.append(threading.Thread(target=self.movieThread, args=(release['href'], release_title)))

        for i in self.threads:
            i.start()

        for i in self.threads:
            i.join()

        return self.torrent_list
