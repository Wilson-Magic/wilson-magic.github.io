# -*- coding: utf-8 -*-

import hosters
import torrent

def get_hosters():
    return hosters.__all__

def get_torrent():
    return torrent.__all__

