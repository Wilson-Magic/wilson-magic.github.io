# -*- coding: utf-8 -*-

'''
    Incursion Add-on

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import requests, threading, traceback, re
from bs4 import BeautifulSoup
from resources.lib.common import source_utils

try:
    from urllib.parse import quote_plus
except ImportError:
    from urllib import quote_plus


class source:
    def __init__(self):
        self.priority = 1
        self.language = ['en']
        self.domain = 'scnsrc.me'
        self.base_link = 'http://rmz.cr/'
        self.search_link = 'http://rmz.cr/search/%s/releases'
        self.source_list = []
        self.threads = []

    def postThread(self, post_title, url):
        response = requests.get(self.base_link + url)
        soup = BeautifulSoup(response.text, 'html.parser')

        try:
            post_title = re.findall(r'\n\n(.*?)Size:', soup.find('div', {'class': 'blog-details'}).text)[0]
        except:
            return

        post_links = soup.find_all('pre', {'class': 'links'})

        for link in post_links:
            clean_title = source_utils.cleanTitle(post_title)
            quality = source_utils.getQuality(clean_title)
            info = source_utils.getInfo(clean_title)
            self.source_list.append({'source': '', 'quality': quality, 'language': 'en', 'url': link.text, 'info': info,
                            'direct': False, 'debridonly': True})

    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            1==1
        except:
            traceback.print_exc()
            return

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):

        url = {'imdb': imdb, 'tvdb': tvdb, 'tvshowtitle': tvshowtitle, 'year': year}
        return url

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        try:
            sources = []

            query = '%s s%se%s' % (url['tvshowtitle'], season, episode)
            search_url = self.search_link % quote_plus(query)
            try:
                response = requests.get(search_url, timeout=10)
            except requests.exceptions.ReadTimeout:
                return None
            soup = BeautifulSoup(response.text, 'html.parser')
            soup = soup.find('div', 'list_items')
            soup = soup.find_all('a', {'class': 'title'})
            post_list = []

            for i in soup:
                post_title = re.findall(r'\[.*?\] (.*?)$', i.text.lower())[0]
                if post_title.startswith(query.lower()):
                    post_list.append(i['href'])

            for i in post_list:
                self.threads.append(threading.Thread(target=self.postThread, args=(post_title, i,)))

            for i in self.threads:
                i.start()

            for i in self.threads:
                i.join()

            return self.source_list

        except:
            traceback.print_exc()
            return

    def sources(self, url, hostDict, hostprDict):
        sources = []
        hostDict = hostDict + hostprDict
        filtered_list = []
        if url is None: return

        for i in url:
            for h in hostDict:
                if h in i['url']:
                    i['source'] = h
                    filtered_list.append(i)


        return filtered_list

    def resolve(self, url):
        return url



